from wordle.wordle import Wordle

from wordle.randomanswer import random_answer