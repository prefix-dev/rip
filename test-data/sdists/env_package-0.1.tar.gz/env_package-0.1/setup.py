import os
from setuptools import setup

if __name__ == '__main__':
    
    env_value = os.environ.get('MY_ENV_VAR')

    assert env_value, "MY_ENV_VAR should be set in order to build wheel"

    setup(
        name='env_package',
        version='0.1',
        packages=['env_package'],
      )

